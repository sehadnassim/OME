//==============================================================================
//
//  OvenMediaEngine
//
//  Created by Hyunjun Jang
//  Copyright (c) 2018 AirenSoft. All rights reserved.
//
//==============================================================================
#pragma once

#include "rtc_ice_candidate.h"

#include "rtc_signalling_observer.h"
#include "rtc_signalling_server.h"
