#pragma once

#include "rtcp_packet_header.h"

enum RtcpPacketType
{
    SenderReport = 200
};
