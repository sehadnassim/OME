//==============================================================================
//
//  OvenMediaEngine
//
//  Created by Hyunjun Jang
//  Copyright (c) 2018 AirenSoft. All rights reserved.
//
//==============================================================================
#pragma once

#include <limits.h>

namespace ov
{
	// 무한정 대기하는 timeout 값
	const int Infinite = INT_MAX;
}
